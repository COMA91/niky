package kr.co.shop.manager.repository;

public interface ManagerDAO {

}
