package kr.co.shop.manager.service;

public interface ManagerService {

}
