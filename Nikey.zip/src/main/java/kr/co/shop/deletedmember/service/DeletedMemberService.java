package kr.co.shop.deletedmember.service;

public interface DeletedMemberService {

}
