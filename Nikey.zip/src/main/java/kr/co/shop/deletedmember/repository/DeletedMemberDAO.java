package kr.co.shop.deletedmember.repository;

public interface DeletedMemberDAO {

}
