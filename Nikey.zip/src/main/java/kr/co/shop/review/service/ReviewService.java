package kr.co.shop.review.service;

public interface ReviewService {

}
