package kr.co.shop.review.repository;

public interface ReviewDAO {

}
