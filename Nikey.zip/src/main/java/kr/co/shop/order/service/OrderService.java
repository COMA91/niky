package kr.co.shop.order.service;

public interface OrderService {

}
