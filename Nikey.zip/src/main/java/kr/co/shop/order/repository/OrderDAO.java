package kr.co.shop.order.repository;

public interface OrderDAO {

}
