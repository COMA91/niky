package kr.co.shop.customer.service;

import kr.co.shop.customer.domain.CustomerDTO;

public interface CustomerService {

	void insert(CustomerDTO dto);

}
