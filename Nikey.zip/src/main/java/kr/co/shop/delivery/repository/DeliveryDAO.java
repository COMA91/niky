package kr.co.shop.delivery.repository;

public interface DeliveryDAO {
	
}
