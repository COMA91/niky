package kr.co.shop.delivery.service;

import kr.co.shop.delivery.domain.DeliveryDTO;

public interface DeliveryService {

	

}
