package kr.co.shop.product.service;

public interface ProductService {

}
