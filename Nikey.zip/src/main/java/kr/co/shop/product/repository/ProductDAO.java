package kr.co.shop.product.repository;

public interface ProductDAO {

}
