package kr.co.shop.refund.repository;

public interface RefundDAO {

}
